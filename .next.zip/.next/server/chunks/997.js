"use strict";
exports.id = 997;
exports.ids = [997];
exports.modules = {

/***/ 3997:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M_": () => (/* binding */ UpdateOrderPayment),
/* harmony export */   "gJ": () => (/* binding */ GetPaymentInfo),
/* harmony export */   "my": () => (/* binding */ UpdateOrderCheckoutPayment)
/* harmony export */ });
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6037);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client__WEBPACK_IMPORTED_MODULE_0__]);
_api_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const UpdateOrderPayment = async (id, data)=>{
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/v1/Order/updateOrder/${id}`, data)).data;
        alert("Order added successfully");
        return true;
    } catch (error) {
        console.log("Error creating products", error.response || error);
        return false;
    }
};
const GetPaymentInfo = async (dispatch)=>{
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/api/v1/PaymentInfo/getPaymentInfo")).data;
        console.log(p, "payment");
        dispatch({
            type: "FETCHED_DATA",
            payload: p.data
        });
    // alert("Order added successfully");
    // return true;
    } catch (error) {
        console.log("Error getting payment info", error.response || error);
        return false;
    }
};
const UpdateOrderCheckoutPayment = async (data)=>{
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/v1/Order/updateCheckout`, data)).data;
        alert("Order added successfully");
        return true;
    } catch (error) {
        console.log("Error creating products", error.response || error);
        return false;
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;