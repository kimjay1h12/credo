"use strict";
exports.id = 777;
exports.ids = [777];
exports.modules = {

/***/ 7622:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ getAllCustomers)
/* harmony export */ });
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6037);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client__WEBPACK_IMPORTED_MODULE_0__]);
_api_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getAllCustomers = async (dispatch)=>{
    // dispatch({
    //   type: "LOADING",
    // });
    try {
        const p = await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/Customer/getCustomers`);
        console.log("Customers", p.data.data);
        dispatch({
            type: "FETCHED_DATA",
            payload: p.data?.data
        });
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message || "Couldn't get cart"
        });
        console.log("Error Getting Customers", error.response);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9051:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ getAllOrders)
/* harmony export */ });
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6037);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client__WEBPACK_IMPORTED_MODULE_0__]);
_api_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getAllOrders = async (dispatch)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/Order/getOrders?pageSize=10000`)).data;
        dispatch({
            type: "FETCHED_DATA",
            payload: p.data
        });
    // console.log("products", p.data);
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message || "Couldn't get cart"
        });
        console.log("Error all orders", error.response);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2777:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ MiniDrawer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Dashboard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7235);
/* harmony import */ var _mui_icons_material_Dashboard__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Dashboard__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3882);
/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Drawer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7898);
/* harmony import */ var _mui_material_Drawer__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Drawer__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1431);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_AddBox__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(976);
/* harmony import */ var _mui_icons_material_AddBox__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddBox__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_Analytics__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5041);
/* harmony import */ var _mui_icons_material_Analytics__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Analytics__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_Apps__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7095);
/* harmony import */ var _mui_icons_material_Apps__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Apps__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6959);
/* harmony import */ var _mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2818);
/* harmony import */ var _mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3365);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_icons_material_MoreHoriz__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5453);
/* harmony import */ var _mui_icons_material_MoreHoriz__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_MoreHoriz__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_icons_material_NotificationsNone__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3173);
/* harmony import */ var _mui_icons_material_NotificationsNone__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_NotificationsNone__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1939);
/* harmony import */ var _mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_icons_material_Sell__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7026);
/* harmony import */ var _mui_icons_material_Sell__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Sell__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(32);
/* harmony import */ var _mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(4960);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(4192);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_mui_material_List__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _mui_material_ListItem__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(834);
/* harmony import */ var _mui_material_ListItem__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(1011);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(3787);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(8315);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(5144);
/* harmony import */ var _context_actions_categoryAction__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(6966);
/* harmony import */ var _context_actions_collectionAction__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(9224);
/* harmony import */ var _context_actions_cutomersctions__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(7622);
/* harmony import */ var _context_actions_productsActions__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(9026);
/* harmony import */ var _context_actions_auth__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(6095);
/* harmony import */ var _context_actions_orderAction__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(9051);
/* harmony import */ var _context_actions_paymentAction__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(3997);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context__WEBPACK_IMPORTED_MODULE_31__, _context_actions_categoryAction__WEBPACK_IMPORTED_MODULE_32__, _context_actions_collectionAction__WEBPACK_IMPORTED_MODULE_33__, _context_actions_cutomersctions__WEBPACK_IMPORTED_MODULE_34__, _context_actions_productsActions__WEBPACK_IMPORTED_MODULE_35__, _context_actions_auth__WEBPACK_IMPORTED_MODULE_36__, _context_actions_orderAction__WEBPACK_IMPORTED_MODULE_37__, _context_actions_paymentAction__WEBPACK_IMPORTED_MODULE_38__]);
([_context__WEBPACK_IMPORTED_MODULE_31__, _context_actions_categoryAction__WEBPACK_IMPORTED_MODULE_32__, _context_actions_collectionAction__WEBPACK_IMPORTED_MODULE_33__, _context_actions_cutomersctions__WEBPACK_IMPORTED_MODULE_34__, _context_actions_productsActions__WEBPACK_IMPORTED_MODULE_35__, _context_actions_auth__WEBPACK_IMPORTED_MODULE_36__, _context_actions_orderAction__WEBPACK_IMPORTED_MODULE_37__, _context_actions_paymentAction__WEBPACK_IMPORTED_MODULE_38__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







































const drawerWidth = 240;
const routes = [
    {
        label: "Home",
        path: "/",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Apps__WEBPACK_IMPORTED_MODULE_10___default()), {}),
        active: "home"
    },
    {
        label: "My Orders",
        path: "/dashboard/orders",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AddBox__WEBPACK_IMPORTED_MODULE_8___default()), {}),
        active: "orders"
    },
    {
        label: "Product",
        path: "/dashboard/products",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_MoreHoriz__WEBPACK_IMPORTED_MODULE_14___default()), {}),
        active: "product"
    },
    {
        label: "Category",
        path: "/dashboard/category",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_16___default()), {}),
        active: "category"
    },
    {
        label: "Customers",
        path: "/dashboard/customers",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Sell__WEBPACK_IMPORTED_MODULE_17___default()), {}),
        active: "customer"
    },
    {
        label: "Collections",
        path: "/dashboard/collections",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Analytics__WEBPACK_IMPORTED_MODULE_9___default()), {}),
        active: "collections"
    },
    {
        label: "Analytic",
        path: "/dashboard/analytics",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Dashboard__WEBPACK_IMPORTED_MODULE_1___default()), {}),
        active: "analytic"
    },
    {
        label: "Payment Settings",
        path: "/dashboard/paymentsettings",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_18___default()), {}),
        active: "paymentsettings"
    }, 
];
const openedMixin = (theme)=>({
        width: drawerWidth,
        transition: theme.transitions.create("width", {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen
        }),
        overflowX: "hidden"
    });
const closedMixin = (theme)=>({
        transition: theme.transitions.create("width", {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        }),
        overflowX: "hidden",
        width: `calc(${theme.spacing(7)} + 1px)`,
        [theme.breakpoints.up("sm")]: {
            width: `calc(${theme.spacing(8)} + 1px)`
        }
    });
const DrawerHeader = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_6__.styled)("div")(({ theme  })=>({
        display: "flex",
        alignItems: "center",
        justifyContent: "flex-end",
        padding: theme.spacing(0, 1),
        background: "#fff",
        // necessary for content to be below app bar
        ...theme.mixins.toolbar
    }));
const AppBar = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_6__.styled)((_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2___default()), {
    shouldForwardProp: (prop)=>prop !== "open"
})(({ theme , open  })=>({
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create([
            "width",
            "margin"
        ], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        }),
        ...open && {
            marginLeft: drawerWidth,
            width: `calc(100% - ${drawerWidth}px)`,
            transition: theme.transitions.create([
                "width",
                "margin"
            ], {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen
            })
        }
    }));
const Drawer = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_6__.styled)((_mui_material_Drawer__WEBPACK_IMPORTED_MODULE_4___default()), {
    shouldForwardProp: (prop)=>prop !== "open"
})(({ theme , open  })=>({
        width: drawerWidth,
        flexShrink: 0,
        whiteSpace: "nowrap",
        boxSizing: "border-box",
        ...open && {
            ...openedMixin(theme),
            "& .MuiDrawer-paper": openedMixin(theme)
        },
        ...!open && {
            ...closedMixin(theme),
            "& .MuiDrawer-paper": closedMixin(theme)
        }
    }));
function MiniDrawer({ children , active  }) {
    const { authState: { loggedIn , data , setup_data  } , productDispatch , cartDispatch , authDispatch , orderDispatch , cartState , collectionsDispatch , cartegoryDispatch , adminProductsDispatch , customerDispatch , paymentDispatch ,  } = react__WEBPACK_IMPORTED_MODULE_7__.useContext(_context__WEBPACK_IMPORTED_MODULE_31__/* .GlobalContext */ .k);
    // const { cartState } = useContext(GlobalContext);
    react__WEBPACK_IMPORTED_MODULE_7__.useEffect(()=>{
        setTimeout(()=>{
            (0,_context_actions_productsActions__WEBPACK_IMPORTED_MODULE_35__/* .getAllUserProducts */ .PB)(productDispatch);
            (0,_context_actions_orderAction__WEBPACK_IMPORTED_MODULE_37__/* .getAllOrders */ .z)(orderDispatch);
            (0,_context_actions_categoryAction__WEBPACK_IMPORTED_MODULE_32__/* .getAllCategory */ .KQ)(cartegoryDispatch);
            (0,_context_actions_collectionAction__WEBPACK_IMPORTED_MODULE_33__/* .getAllCollections */ .Lg)(collectionsDispatch);
            (0,_context_actions_productsActions__WEBPACK_IMPORTED_MODULE_35__/* .getAllAdminProducts */ .c0)(adminProductsDispatch);
            (0,_context_actions_cutomersctions__WEBPACK_IMPORTED_MODULE_34__/* .getAllCustomers */ .J)(customerDispatch);
            (0,_context_actions_paymentAction__WEBPACK_IMPORTED_MODULE_38__/* .GetPaymentInfo */ .gJ)(paymentDispatch);
        }, 500);
    // client.defaults.headers.common["Authorization"] = `Bearer ${data.token}`;
    }, [
        data.token
    ]);
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_6__.useTheme)();
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_7__.useState(true);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_30__.useRouter)();
    const handleDrawerOpen = ()=>{
        setOpen(true);
    };
    const handleDrawerClose = ()=>{
        setOpen(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
        sx: {
            display: "flex",
            boxShadow: 0
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_21___default()), {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AppBar, {
                sx: {
                    background: "#fff",
                    boxShadow: 1,
                    color: "#000"
                },
                position: "fixed",
                open: open,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_5___default()), {
                    sx: {
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_23___default()), {
                            color: "inherit",
                            "aria-label": "open drawer",
                            onClick: handleDrawerOpen,
                            edge: "start",
                            sx: {
                                marginRight: 5,
                                ...open && {
                                    display: "none"
                                }
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_13___default()), {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_19__.TextField, {
                            placeholder: "Search",
                            size: "small",
                            sx: {
                                background: "#F1F1F1"
                            }
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            style: {
                                display: "flex",
                                gap: 10,
                                alignItems: "center"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_19__.ButtonBase, {
                                    sx: {
                                        background: "#f1f1f1",
                                        borderRadius: 30,
                                        padding: 1
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_NotificationsNone__WEBPACK_IMPORTED_MODULE_15___default()), {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_19__.Avatar, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    style: {
                                        display: "flex",
                                        flexDirection: "column"
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_29___default()), {
                                            variant: "caption",
                                            fontWeight: 700,
                                            children: data?.user?.fullName
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_29___default()), {
                                            variant: "caption",
                                            children: [
                                                " ",
                                                data?.user?.email
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Drawer, {
                sx: {
                    boxShadow: 1
                },
                variant: "permanent",
                open: open,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(DrawerHeader, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/img/logo.png",
                                style: {
                                    height: 40,
                                    width: 100,
                                    objectFit: "contain",
                                    position: "absolute",
                                    left: 10
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_23___default()), {
                                style: {
                                    display: "flex",
                                    justifyContent: "flex-end"
                                },
                                onClick: handleDrawerClose,
                                children: theme.direction === "rtl" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_12___default()), {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_11___default()), {})
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_22___default()), {
                        sx: {
                            marginLeft: 2,
                            marginRight: 2
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_29___default()), {
                        mt: 3,
                        variant: "caption",
                        ml: 2.8,
                        color: "#B2B8BD",
                        children: "MAIN MENU"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_List__WEBPACK_IMPORTED_MODULE_24___default()), {
                        children: routes.map((text, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_25___default()), {
                                disablePadding: true,
                                sx: {
                                    display: "block"
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_26___default()), {
                                    onClick: ()=>{
                                        router.push(text.path);
                                    },
                                    sx: {
                                        backgroundColor: active === text.active && "#EFF6FF",
                                        minHeight: 48,
                                        justifyContent: open ? "initial" : "center",
                                        px: 2.5,
                                        marginBottom: 2
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_27___default()), {
                                            sx: {
                                                minWidth: 0,
                                                mr: open ? 3 : "auto",
                                                justifyContent: "center"
                                            },
                                            children: text.icon
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_28___default()), {
                                            primary: text.label,
                                            sx: {
                                                opacity: open ? 1 : 0
                                            }
                                        })
                                    ]
                                })
                            }, text))
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: {
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "flex-end",
                            height: "100%",
                            padding: 15
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_20___default()), {
                            variant: "contained",
                            sx: {
                                background: "red"
                            },
                            onClick: ()=>{
                                const r = (0,_context_actions_auth__WEBPACK_IMPORTED_MODULE_36__/* .logoutHandler */ .Sl)(authDispatch);
                                if (r) {
                                    router.push("/");
                                }
                            },
                            children: [
                                " ",
                                "Log Out"
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
                component: "main",
                sx: {
                    flexGrow: 1,
                    // height: "100%",
                    background: "#EFF6FF",
                    minHeight: "100vh"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DrawerHeader, {}),
                    children
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;