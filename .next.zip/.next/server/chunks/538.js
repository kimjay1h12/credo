"use strict";
exports.id = 538;
exports.ids = [538];
exports.modules = {

/***/ 6966:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JP": () => (/* binding */ createAdminCategory),
/* harmony export */   "KQ": () => (/* binding */ getAllCategory),
/* harmony export */   "kX": () => (/* binding */ deleteAdminCategory)
/* harmony export */ });
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6037);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client__WEBPACK_IMPORTED_MODULE_0__]);
_api_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getAllCategory = async (dispatch)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/Category/getCategories?pageSize=10000`)).data;
        console.log("cartegory", p);
        dispatch({
            type: "FETCHED_DATA",
            payload: p.data
        });
        console.log(p.data);
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message || "Couldn't get cart"
        });
        console.log("Error Getting Collections", error.response);
    }
};
const createAdminCategory = async (dispatch, data)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/v1/Category/addCategory`, data)).data;
        console.log("cartegory", p);
        getAllCategory(dispatch);
        return true;
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message || "Couldn't get cart"
        });
        console.log("Error Getting Collections", error.response);
    }
};
const deleteAdminCategory = async (dispatch, data)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/api/v1/Category/deleteCategory/${data}`)).data;
        // console.log("cartegory", p);
        getAllCategory(dispatch);
        alert("Category deleted successfully");
        return true;
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message
        });
        console.log("Error deleting category", error.response);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9224:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Lg": () => (/* binding */ getAllCollections),
/* harmony export */   "jK": () => (/* binding */ createAdminCollections),
/* harmony export */   "mB": () => (/* binding */ deleteAdminCollections)
/* harmony export */ });
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6037);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client__WEBPACK_IMPORTED_MODULE_0__]);
_api_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getAllCollections = async (dispatch)=>{
    // dispatch({
    //   type: "LOADING",
    // });
    try {
        const p = await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/Collection/getCollections`);
        console.log("collections", p.data.data);
        dispatch({
            type: "FETCHED_DATA",
            payload: p.data?.data
        });
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message || "Couldn't get cart"
        });
        console.log("Error Getting Collections", error.response);
    }
};
const createAdminCollections = async (dispatch, data)=>{
    // dispatch({
    //   type: "LOADING",
    // });
    try {
        const p = await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/v1/Collection/addCollection?pageSize=10000`, data);
        getAllCollections(dispatch);
        return true;
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message || "Couldn't get cart"
        });
        alert(error.response?.data?.message);
        console.log("Error Getting Collections", error.response);
    }
};
const deleteAdminCollections = async (dispatch, data)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/api/v1/Collection/deleteCollection/${data}`)).data;
        // console.log("cartegory", p);
        getAllCategory(dispatch);
        alert("Collections deleted successfully");
        return true;
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message
        });
        console.log("Error deleting collection", error.response);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9026:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Gq": () => (/* binding */ deleteAdminProducts),
/* harmony export */   "PB": () => (/* binding */ getAllUserProducts),
/* harmony export */   "c0": () => (/* binding */ getAllAdminProducts),
/* harmony export */   "mZ": () => (/* binding */ createAdminProducts)
/* harmony export */ });
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6037);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client__WEBPACK_IMPORTED_MODULE_0__]);
_api_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getAllUserProducts = async (dispatch)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/Product/getAllProducts?pageSize=10000`)).data;
        dispatch({
            type: "FETCHED_DATA",
            payload: p.data
        });
    // console.log("products", p.data);
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message || "Couldn't get cart"
        });
        console.log("Error all products", error.response);
    }
};
const getAllAdminProducts = async (dispatch)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/Product/getUserProducts`)).data;
        dispatch({
            type: "FETCHED_DATA",
            payload: p.data
        });
    // console.log("products", p.data);
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message || "Couldn't get cart"
        });
        console.log("Error all admin products", error.response);
    }
};
const createAdminProducts = async (dispatch, data)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/v1/Product/addProduct`, data)).data;
        getAllAdminProducts(dispatch);
        // console.log("products", p);
        alert("Product Created Successfully");
        return true;
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message || "Couldn't get cart"
        });
        console.log("Error creating products", error.response || error);
        return false;
    }
};
const deleteAdminProducts = async (dispatch, data)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/api/v1/Product/deleteProduct/${data}`)).data;
        // console.log("cartegory", p);
        getAllUserProducts(dispatch);
        alert("Products deleted successfully");
        return true;
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message
        });
        console.log("Error deleting collection", error.response);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;