"use strict";
exports.id = 81;
exports.ids = [81];
exports.modules = {

/***/ 8081:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BasicTable)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9181);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Table__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8823);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(443);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_TableHead__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5953);
/* harmony import */ var _mui_material_TableHead__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableHead__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4848);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1168);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _utility__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3712);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utility__WEBPACK_IMPORTED_MODULE_11__]);
_utility__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












function createData(name, calories, fat, carbs, protein) {
    return {
        name,
        calories,
        fat,
        carbs,
        protein
    };
}
// const rows = [
//   {
//     orderid: "CR 001",
//     phone: "08123456789",
//     status: "Paid",
//     date: "Sep 11, 2:45PM",
//     amount: "$50.00",
//   },
//   {
//     orderid: "CR 001",
//     phone: "08123456789",
//     status: "Paid",
//     date: "Sep 11, 2:45PM",
//     amount: "$50.00",
//   },
//   {
//     orderid: "CR 001",
//     phone: "08123456789",
//     status: "Paid",
//     date: "Sep 11, 2:45PM",
//     amount: "$50.00",
//   },
//   {
//     orderid: "CR 001",
//     phone: "08123456789",
//     status: "Paid",
//     date: "Sep 11, 2:45PM",
//     amount: "$50.00",
//   },
//   {
//     orderid: "CR 001",
//     phone: "08123456789",
//     status: "Paid",
//     date: "Sep 11, 2:45PM",
//     amount: "$50.00",
//   },
//   {
//     orderid: "CR 001",
//     phone: "08123456789",
//     status: "Paid",
//     date: "Sep 11, 2:45PM",
//     amount: "$50.00",
//   },
//   {
//     orderid: "CR 001",
//     phone: "08123456789",
//     status: "Paid",
//     date: "Sep 11, 2:45PM",
//     amount: "$50.00",
//   },
//   {
//     orderid: "CR 001",
//     phone: "08123456789",
//     status: "Paid",
//     date: "Sep 11, 2:45PM",
//     amount: "$50.00",
//   },
//   {
//     orderid: "CR 001",
//     phone: "08123456789",
//     status: "Paid",
//     date: "Sep 11, 2:45PM",
//     amount: "$50.00",
//   },
//   {
//     orderid: "CR 001",
//     phone: "08123456789",
//     status: "Paid",
//     date: "Sep 11, 2:45PM",
//     amount: "$50.00",
//   },
// ];
function BasicTable({ rows  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_5___default()), {
        sx: {
            background: "#fff",
            borderRadius: 3
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: 15
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                        fontWeight: 600,
                        children: "Recent Orders"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_9__.Button, {
                        onClick: ()=>{
                            router.push("/dashboard/orders");
                        },
                        children: "See All"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Table__WEBPACK_IMPORTED_MODULE_2___default()), {
                sx: {
                    minWidth: 650
                },
                "aria-label": "simple table",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableHead__WEBPACK_IMPORTED_MODULE_6___default()), {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_7___default()), {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    children: "Order Id"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    align: "right",
                                    children: "Phone"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    align: "right",
                                    children: "Payment Status"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    align: "right",
                                    children: "Date"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    align: "right",
                                    children: "Amount"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_3___default()), {
                        children: rows.map((row, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_7___default()), {
                                onClick: ()=>{
                                    // router.push("/dashboard/orders/view/" + 34567);
                                    router.push({
                                        pathname: "/dashboard/orders/view/",
                                        query: {
                                            data: JSON.stringify(row)
                                        }
                                    });
                                },
                                sx: {
                                    "&:last-child td, &:last-child th": {
                                        border: 0
                                    },
                                    cursor: "pointer",
                                    "&:hover td ": {
                                        background: "#f7f7f7"
                                    },
                                    "&:hover th ": {
                                        background: "#f7f7f7"
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        component: "th",
                                        scope: "row",
                                        children: row.orderId
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        align: "right",
                                        children: row.billingInfo?.phoneNumber
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        align: "right",
                                        style: {
                                            color: row.paymentStatus === "pending" ? "#FBBB00" : row.paymentStatus === "paid" ? "#00CC08" : "red"
                                        },
                                        children: row.paymentStatus
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        align: "right",
                                        children: (0,_utility__WEBPACK_IMPORTED_MODULE_11__/* .formatDateAndTime */ .sb)(row.date)?.formattedDate
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        align: "right",
                                        children: (0,_utility__WEBPACK_IMPORTED_MODULE_11__/* .currencyFormatter */ .oB)(row.amount)
                                    })
                                ]
                            }, i))
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;