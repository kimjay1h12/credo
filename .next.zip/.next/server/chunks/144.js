"use strict";
exports.id = 144;
exports.ids = [144];
exports.modules = {

/***/ 6037:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export config */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const config = {
    baseURL: "https://api.credoculture.com/"
};
let token;
if (false) {}
const client = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: config.baseURL,
    headers: {
        Authorization: `Bearer ${token}`
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (client);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6095:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Sl": () => (/* binding */ logoutHandler),
/* harmony export */   "WC": () => (/* binding */ forgottenpassword),
/* harmony export */   "dx": () => (/* binding */ resendPassword),
/* harmony export */   "hK": () => (/* binding */ signInHandler),
/* harmony export */   "lQ": () => (/* binding */ signupHandler),
/* harmony export */   "qD": () => (/* binding */ verifyOTP),
/* harmony export */   "ts": () => (/* binding */ getCurrentUser)
/* harmony export */ });
/* unused harmony exports resendOtp, setupPin */
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6037);
/* harmony import */ var _cart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4235);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client__WEBPACK_IMPORTED_MODULE_0__, _cart__WEBPACK_IMPORTED_MODULE_1__]);
([_api_client__WEBPACK_IMPORTED_MODULE_0__, _cart__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const signupHandler = async (data, dispatch)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const res = await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/Auth/register", data);
        // console.log("signup", res.data.data?.user);
        localStorage.setItem("nd-rest-tkn", res.data.data?.authToken);
        localStorage.setItem("userData", JSON.stringify(res.data.data?.user));
        // localStorage.removeItem("setupStore");
        _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].defaults.headers.post["Content-Type"] */ .Z.defaults.headers.post["Content-Type"] = "application/json";
        _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].defaults.headers.Authorization */ .Z.defaults.headers.Authorization = `Bearer ${res.data.data?.authToken}`;
        dispatch({
            type: "SUCCESS",
            payload: res.data.data
        });
        return true;
    } catch (error) {
        console.log("Error", error.response.data);
        alert(error?.response?.data?.message);
        dispatch({
            type: "ERROR",
            payload: error?.response?.data?.message
        });
        return false;
    }
};
const resendOtp = async (data, dispatch)=>{
    // return alert(data.otp, data.email);
    console.log("data", data);
    dispatch({
        type: "LOADING"
    });
    try {
        const res = await client.post("business/resendOTPEmailVerification", data);
        return true;
    } catch (error) {
        console.log("Error", error.response);
        alert(error?.response?.data?.message);
        dispatch({
            type: "ERROR",
            payload: error?.response?.data?.message
        });
        return false;
    }
};
const forgottenpassword = async (data, dispatch)=>{
    // return alert(data.otp, data.email);
    // console.log("data", data);
    dispatch({
        type: "LOADING"
    });
    try {
        const res = await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/Auth/forgotPassword/", data);
        console.log("forgotten password", res);
        return true;
    } catch (error) {
        console.log("Error", error.response);
        alert(error?.response?.data?.message);
        dispatch({
            type: "ERROR",
            payload: error?.response?.data?.message
        });
        return false;
    }
};
const resendPassword = async (data, dispatch)=>{
    // return alert(data.otp, data.email);
    // console.log("data", data);
    dispatch({
        type: "LOADING"
    });
    try {
        const res = await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/Auth/resetPassword", data);
        return true;
    } catch (error) {
        console.log("Error", error.response);
        dispatch({
            type: "ERROR",
            payload: error?.response?.data?.message
        });
        return false;
    }
};
const verifyOTP = async (data, dispatch)=>{
    // return alert(data.otp, data.email);
    console.log("data", data);
    dispatch({
        type: "LOADING"
    });
    try {
        const res = await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/Auth/verifyOtpCodePasswordReset", data);
        // localStorage.setItem("nd-rest-tkn", res.data.data?.authToken);
        // client.defaults.headers.post["Content-Type"] = "application/json";
        // client.defaults.headers.Authorization = `Bearer ${res.data.data?.authToken}`;
        // console.log("success", res.data);
        // dispatch({
        //   type: "SUCCESS",
        //   payload: res.data.data,
        // });
        return true;
    } catch (error) {
        console.log("Error", error.response);
        dispatch({
            type: "ERROR",
            payload: error?.response?.data?.message
        });
        return false;
    }
};
const signInHandler = async (data, dispatch)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const res = await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/Auth/login", data);
        localStorage.setItem("nd-rest-tkn", res.data.data?.authToken);
        localStorage.setItem("userData", JSON.stringify(res.data.data?.user));
        // localStorage.removeItem("setupStore");
        _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].defaults.headers.post["Content-Type"] */ .Z.defaults.headers.post["Content-Type"] = "application/json";
        _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].defaults.headers.Authorization */ .Z.defaults.headers.Authorization = `Bearer ${res.data.data?.authToken}`;
        dispatch({
            type: "SUCCESS",
            payload: res.data.data
        });
        getCurrentUser(dispatch);
        return true;
    } catch (error) {
        alert(error?.response?.data?.message);
        console.log("Error", error.response);
        dispatch({
            type: "ERROR",
            payload: error?.response?.data?.message
        });
        return false;
    }
};
const setupPin = async (data, dispatch)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const res = await client.post("business/setupPin", data);
        // localStorage.setItem("nd-rest-tkn", res.data.data?.authToken);
        // localStorage.setItem("userData", JSON.stringify(res.data.data));
        // dispatch({
        //   type: "SUCCESS",
        //   payload: res.data.data,
        // });
        // getCurrentUser(dispatch);
        return true;
    } catch (error) {
        console.log("Error", error.response);
        dispatch({
            type: "ERROR",
            payload: error?.response?.data?.message
        });
        return false;
    }
};
const logoutHandler = (dispatch)=>{
    dispatch({
        type: "LOGOUT"
    });
    localStorage.clear();
    return true;
};
const getCurrentUser = async (dispatch)=>{
    const user = localStorage.getItem("userData");
    const authToken = localStorage.getItem("nd-rest-tkn");
    // const stored_setup_data = localStorage.getItem("setup_data");
    _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].defaults.headers.post["Content-Type"] */ .Z.defaults.headers.post["Content-Type"] = "application/json";
    _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].defaults.headers.Authorization */ .Z.defaults.headers.Authorization = `Bearer ${authToken}`;
    console.log("user", user);
    if (user) {
        dispatch({
            type: "SUCCESS",
            payload: JSON.parse(user)
        });
        console.log("setupid", JSON.parse(user).id);
        try {
            const res = await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/Auth/getUser`);
            console.log("setupdata", res);
            // localStorage.setItem("nd-rest-tkn", res.data.data?.authToken);
            localStorage.setItem("userData", JSON.stringify(res.data.data));
            // // localStorage.removeItem("setupStore");
            // client.defaults.headers.post["Content-Type"] = "application/json";
            // client.defaults.headers.Authorization = `Bearer ${res.data.data?.authToken}`;
            const payload = {
                user: res.data.data,
                authToken: authToken
            };
            console.log("userdata", payload);
            dispatch({
                type: "SUCCESS",
                payload: payload
            });
        } catch (error) {
            logoutHandler(dispatch);
            console.log("Couldn't get user", error);
        }
    } else logoutHandler(dispatch);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4235:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ getCart)
/* harmony export */ });
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6037);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client__WEBPACK_IMPORTED_MODULE_0__]);
_api_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getCart = async (dispatch)=>{
    dispatch({
        type: "LOADING"
    });
    try {
        const p = (await _api_client__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/Cart/getCartItems`)).data;
        dispatch({
            type: "FETCHED_DATA",
            payload: p.data
        });
        console.log(p.data);
    } catch (error) {
        dispatch({
            type: "ERROR",
            payload: error.response?.data?.message || "Couldn't get cart"
        });
        console.log("Error Getting Cart", error.response);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5144:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ GlobalProvider),
/* harmony export */   "k": () => (/* binding */ GlobalContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6037);
/* harmony import */ var _actions_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6095);
/* harmony import */ var _actions_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4235);
/* harmony import */ var _reducers_authReducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7614);
/* harmony import */ var _reducers_cartReducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6009);
/* harmony import */ var _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7616);
/* harmony import */ var _reducers_collectionReducer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9279);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client__WEBPACK_IMPORTED_MODULE_2__, _actions_auth__WEBPACK_IMPORTED_MODULE_3__, _actions_cart__WEBPACK_IMPORTED_MODULE_4__]);
([_api_client__WEBPACK_IMPORTED_MODULE_2__, _actions_auth__WEBPACK_IMPORTED_MODULE_3__, _actions_cart__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const genericData = {
    error: null,
    loading: false,
    data: []
};
const GlobalContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext({
    authState: _reducers_authReducer__WEBPACK_IMPORTED_MODULE_5__/* .defaultAuth */ .n,
    authDispatch: ()=>{},
    productState: _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d,
    productDispatch: ()=>{},
    // productState: defaultData,
    cartegoryState: _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d,
    cartegoryDispatch: ()=>{},
    collectionsState: _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d,
    collectionsDispatch: ()=>{},
    cartState: _reducers_cartReducer__WEBPACK_IMPORTED_MODULE_6__/* .defaultCart */ .U,
    cartDispatch: ()=>{},
    orderDispatch: ()=>{},
    orderState: _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d,
    customerState: _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d,
    customerDispatch: ()=>{},
    adminProductsState: _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d,
    adminProductsDispatch: ()=>{},
    paymentState: _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d,
    paymentDispatch: ()=>{}
});
function GlobalProvider({ children  }) {
    const { 0: authState , 1: authDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_reducers_authReducer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, _reducers_authReducer__WEBPACK_IMPORTED_MODULE_5__/* .defaultAuth */ .n);
    const { 0: productState , 1: productDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d);
    // const [productState, productDispatch] = useReducer(genericReducer, defaultData);
    // const [cartbadge, setCartbadge] = useState(0);
    const { 0: cartState , 1: cartDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_reducers_cartReducer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d);
    const { 0: cartegoryState , 1: cartegoryDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d);
    const { 0: adminProductsState , 1: adminProductsDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d);
    const { 0: customerState , 1: customerDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d);
    const { 0: orderState , 1: orderDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d);
    const { 0: collectionsState , 1: collectionsDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d);
    const { 0: paymentState , 1: paymentDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, _reducers_genericReducer__WEBPACK_IMPORTED_MODULE_7__/* .defaultData */ .d);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_actions_auth__WEBPACK_IMPORTED_MODULE_3__/* .getCurrentUser */ .ts)(authDispatch);
    // getCart(cartDispatch);
    }, []);
    // useEffect(() => {
    //   (async () => {
    //     const products = (await client.get("payment/products")).data;
    //     productDispatch({
    //       type: "FETCHED_DATA",
    //       payload: products.data,
    //     });
    //   })();
    // }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(GlobalContext.Provider, {
        value: {
            authState,
            authDispatch,
            productState,
            productDispatch,
            cartState,
            cartDispatch,
            cartegoryDispatch,
            cartegoryState,
            collectionsState,
            collectionsDispatch,
            adminProductsState,
            adminProductsDispatch,
            customerDispatch,
            customerState,
            orderDispatch,
            orderState,
            paymentDispatch,
            paymentState
        },
        children: children
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7614:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ authReducer),
/* harmony export */   "n": () => (/* binding */ defaultAuth)
/* harmony export */ });
function authReducer(state, { payload , type  }) {
    switch(type){
        case "LOADING":
            return {
                ...state,
                error: null,
                loading: true
            };
        case "MODE":
            return {
                ...state,
                mode: payload
            };
        case "SETUP_DATA":
            return {
                ...state,
                setup_data: payload
            };
        case "SUCCESS":
            return {
                ...state,
                error: null,
                loading: false,
                data: payload,
                loggedIn: true
            };
        case "ERROR":
            return {
                ...state,
                loading: false,
                error: payload
            };
        case "LOGOUT":
            return defaultAuth;
        default:
            return {
                ...state,
                loading: false
            };
    }
};
const defaultAuth = {
    loggedIn: false,
    mode: null,
    data: {},
    setup_data: {
        email: ""
    },
    loading: false,
    error: null
};


/***/ }),

/***/ 6009:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ defaultCart),
/* harmony export */   "Z": () => (/* binding */ cartReducer)
/* harmony export */ });
function cartReducer(state, { payload , type  }) {
    switch(type){
        case "LOADING":
            return {
                ...state,
                error: null,
                loading: true
            };
        case "FETCHED_DATA":
            return {
                error: null,
                loading: false,
                data: payload
            };
        case "ERROR":
            return {
                ...state,
                loading: false,
                error: payload
            };
        default:
            return state;
    }
};
const defaultCart = {
    error: null,
    data: {},
    loading: false
};


/***/ }),

/***/ 9279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports default, defaultCollections */
function collectionReducer(state, { payload , type  }) {
    switch(type){
        case "LOADING":
            return {
                ...state,
                error: null,
                loading: true
            };
        case "FETCHED_DATA":
            return {
                error: null,
                loading: false,
                data: payload
            };
        case "ERROR":
            return {
                ...state,
                loading: false,
                error: payload
            };
        default:
            return state;
    }
};
const defaultCollections = {
    error: null,
    data: [],
    loading: false
};


/***/ }),

/***/ 7616:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ genericReducer),
/* harmony export */   "d": () => (/* binding */ defaultData)
/* harmony export */ });
function genericReducer(state, { payload , type  }) {
    switch(type){
        case "LOADING":
            return {
                ...state,
                error: null,
                loading: true
            };
        case "FETCHED_DATA":
            return {
                error: null,
                loading: false,
                data: payload
            };
        case "ERROR":
            return {
                ...state,
                loading: false,
                error: payload
            };
        default:
            return state;
    }
};
const defaultData = {
    error: null,
    data: [],
    loading: false
};


/***/ })

};
;