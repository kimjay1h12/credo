"use strict";
exports.id = 629;
exports.ids = [629];
exports.modules = {

/***/ 2112:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_RemoveCircleOutline__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9513);
/* harmony import */ var _mui_icons_material_RemoveCircleOutline__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_RemoveCircleOutline__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_Remove__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9509);
/* harmony import */ var _mui_icons_material_Remove__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Remove__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utility__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3712);
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6037);
/* harmony import */ var _context_actions_cart__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4235);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5144);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utility__WEBPACK_IMPORTED_MODULE_5__, _api_client__WEBPACK_IMPORTED_MODULE_6__, _context_actions_cart__WEBPACK_IMPORTED_MODULE_7__, _context__WEBPACK_IMPORTED_MODULE_8__]);
([_utility__WEBPACK_IMPORTED_MODULE_5__, _api_client__WEBPACK_IMPORTED_MODULE_6__, _context_actions_cart__WEBPACK_IMPORTED_MODULE_7__, _context__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function CartItem({ id , noOfItems , product  }) {
    const { cartDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_context__WEBPACK_IMPORTED_MODULE_8__/* .GlobalContext */ .k);
    const RemoveItemFromCart = async ()=>{
        try {
            const res = await _api_client__WEBPACK_IMPORTED_MODULE_6__/* ["default"]["delete"] */ .Z["delete"](`/api/v1/Cart/removeFromCart/${id}`);
            console.log(res);
            (0,_context_actions_cart__WEBPACK_IMPORTED_MODULE_7__/* .getCart */ .d)(cartDispatch);
            alert("Successfully removed Item from Cart");
        } catch (error) {
            console.log("error removing from cart", error);
            alert("error removing from cart");
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: {
            cursor: "pointer",
            display: "flex",
            marginTop: 20,
            marginBottom: 20,
            justifyContent: "space-between"
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    display: "flex",
                    alignItems: "flex-start",
                    gap: 10
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: product?.pictures[0]?.url,
                        style: {
                            width: 80,
                            height: 80
                        }
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        style: {
                            gap: 5
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                variant: "body2",
                                children: product.title
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                fontWeight: 800,
                                variant: "body2",
                                children: [
                                    "Quantity ",
                                    noOfItems
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    alignItems: "flex-end"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        ml: 4,
                        variant: "body2",
                        children: (0,_utility__WEBPACK_IMPORTED_MODULE_5__/* .currencyFormatter */ .oB)(product?.price)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ButtonBase, {
                        onClick: ()=>{
                            RemoveItemFromCart();
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Remove__WEBPACK_IMPORTED_MODULE_4___default()), {
                            style: {
                                background: "#aaa",
                                borderRadius: 20
                            }
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartItem);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 332:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9484);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8611);
/* harmony import */ var _mui_material_Dialog__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Dialog__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_DialogContent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1094);
/* harmony import */ var _mui_material_DialogContent__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_DialogContent__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _CartItem__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2112);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5144);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CartItem__WEBPACK_IMPORTED_MODULE_8__, _context__WEBPACK_IMPORTED_MODULE_10__]);
([_CartItem__WEBPACK_IMPORTED_MODULE_8__, _context__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// TopRightDialog.js












const useStyles = (0,_mui_styles__WEBPACK_IMPORTED_MODULE_2__.makeStyles)({
    dialogPaper: {
        position: "absolute",
        top: "-5%",
        width: "100%",
        marginLeft: 20,
        marginRight: 20,
        ["@media (min-width : 1200px)"]: {
            position: "absolute",
            top: 20,
            right: 20,
            width: "100%",
            maxWidth: 500
        }
    },
    row: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 10
    }
});
const TopRightDialog = ({ open , onClose , message , data  })=>{
    // console.log("cartState", data);
    const { authState: { loggedIn  } ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context__WEBPACK_IMPORTED_MODULE_10__/* .GlobalContext */ .k);
    const classes = useStyles();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Dialog__WEBPACK_IMPORTED_MODULE_3___default()), {
        open: open,
        onClose: onClose,
        classes: {
            paper: classes.dialogPaper
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_DialogContent__WEBPACK_IMPORTED_MODULE_4___default()), {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classes.row,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {
                            children: "My cart"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ButtonBase, {
                            onClick: ()=>{
                                onClose();
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_6___default()), {})
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Divider, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {
                    mt: 2,
                    fontWeight: 600,
                    children: "Cart"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        data?.map((cur, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CartItem__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                ...cur
                            }, i)),
                        loggedIn && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Button, {
                            size: "large",
                            sx: {
                                marginTop: 4
                            },
                            fullWidth: true,
                            variant: "contained",
                            onClick: ()=>{
                                router.push("/checkout/");
                            },
                            children: "Checkout"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TopRightDialog);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3193:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9484);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6037);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5144);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client__WEBPACK_IMPORTED_MODULE_4__, _context__WEBPACK_IMPORTED_MODULE_5__]);
([_api_client__WEBPACK_IMPORTED_MODULE_4__, _context__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const useStyles = (0,_mui_styles__WEBPACK_IMPORTED_MODULE_2__.makeStyles)({
    root: {
        minHeight: "30vh",
        background: "#000",
        color: "#fff",
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "space-between",
        padding: 15,
        ["@media (min-width : 1200px)"]: {
            padding: 50
        }
    },
    center: {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        marginTop: 50,
        marginBottom: 40
    }
});
function Footer() {
    const classes = useStyles();
    const { collectionsState: { data  } ,  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context__WEBPACK_IMPORTED_MODULE_5__/* .GlobalContext */ .k);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const { 0: email , 1: setEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const HandleJoinCommunity = async ()=>{
        setLoading(true);
        try {
            const res = (await _api_client__WEBPACK_IMPORTED_MODULE_4__/* ["default"].post */ .Z.post("/api/v1/Subscribe/joinCommunity", {
                email: email
            })).data;
            setEmail("");
            alert(`Your subscription request was successfully mail will be sent to ${email} `);
            setEmail("");
        } catch (error) {
            console.log("response error", error.response);
        }
        setLoading(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classes.center,
                style: {
                    flexDirection: "column",
                    padding: 15
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        fontWeight: 600,
                        variant: "h6",
                        children: "Join our community"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        align: "center",
                        gutterBottom: true,
                        color: "GrayText",
                        children: "Join our community list, and receive some of the best deals possible."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: {
                            maxWidth: 500,
                            width: "100%",
                            marginTop: 30,
                            marginBottom: 20
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, {
                            type: "email",
                            value: email,
                            onChange: (e)=>{
                                setEmail(e.target.value);
                            },
                            fullWidth: true,
                            size: "small",
                            label: "Enter Your Email"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        onClick: ()=>{
                            HandleJoinCommunity();
                        },
                        disabled: email === "",
                        style: {
                            marginBottom: 20
                        },
                        variant: "contained",
                        children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, {
                            size: 20,
                            style: {
                                color: "#fff"
                            }
                        }) : "Join Now"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classes.root,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    container: true,
                    spacing: 6,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                            item: true,
                            md: 3.5,
                            sm: 6,
                            xs: 6,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                style: {
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: 10
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/img/logo2.png",
                                        style: {
                                            height: 60,
                                            width: 60,
                                            objectFit: "contain"
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        variant: "body2",
                                        children: "Lagos, Nigeria"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        variant: "body2",
                                        children: "+234 5698 8737 73"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        variant: "body2",
                                        children: "Credoculture@gmail.com"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                            item: true,
                            md: 3.5,
                            sm: 6,
                            xs: 6,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                style: {
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: 10
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        variant: "h6",
                                        fontWeight: 700,
                                        children: "Categorires"
                                    }),
                                    [
                                        ...data
                                    ]?.splice(0, 5)?.map((cur, i)=>// <ButtonBase key={i}>
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            sx: {
                                                cursor: "pointer"
                                            },
                                            onClick: ()=>{
                                                router.push("/collections/" + cur.id);
                                            },
                                            variant: "body2",
                                            children: cur.title
                                        }, i))
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2826:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9484);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utility__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3712);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utility__WEBPACK_IMPORTED_MODULE_5__]);
_utility__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const useStyles = (0,_mui_styles__WEBPACK_IMPORTED_MODULE_2__.makeStyles)({
    root: {
        width: "100%",
        // height: 300,
        height: "100%",
        padding: 4,
        borderRadius: 10,
        cursor: "pointer"
    },
    img: {
        height: 160,
        width: "100%",
        objectFit: "contain",
        borderRadius: 10,
        "&:hover": {
            background: "#FCFCFC",
            boxShadow: "1px 1px 1px 1px rgba(0, 0, 0, 0.1)"
        },
        "&::active": {
            background: "#FCFCFC"
        },
        ["@media (min-width : 1200px)"]: {
            height: 200
        }
    }
});
function ProductsItem({ pictures =[] , title , price , id  }) {
    // console.log("id", id);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const classes = useStyles();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        onClick: ()=>{
            router.push("/product/" + id);
        },
        className: classes.root,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: pictures[0]?.url,
                className: classes.img
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "caption",
                fontWeight: 400,
                children: title.slice(0, 20)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                // color={"gray"}
                // style={{ textDecorationLine: "line-through" }}
                variant: "body2",
                // ml={1}
                gutterBottom: true,
                fontWeight: 600,
                children: (0,_utility__WEBPACK_IMPORTED_MODULE_5__/* .currencyFormatter */ .oB)(price)
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsItem);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7661:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_CloseOutlined__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2845);
/* harmony import */ var _mui_icons_material_CloseOutlined__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CloseOutlined__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3365);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9484);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_styles__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1939);
/* harmony import */ var _mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_ShoppingBag__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6983);
/* harmony import */ var _mui_icons_material_ShoppingBag__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ShoppingBag__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _Cart_CartView__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(332);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5144);
/* harmony import */ var _context_actions_auth__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6095);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Cart_CartView__WEBPACK_IMPORTED_MODULE_12__, _context__WEBPACK_IMPORTED_MODULE_13__, _context_actions_auth__WEBPACK_IMPORTED_MODULE_14__]);
([_Cart_CartView__WEBPACK_IMPORTED_MODULE_12__, _context__WEBPACK_IMPORTED_MODULE_13__, _context_actions_auth__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















// import SignUp from "./Section/SignUp";
const useStyles = (0,_mui_styles__WEBPACK_IMPORTED_MODULE_5__.makeStyles)({
    toolbar: {
        background: "#fff",
        color: "#000",
        padding: "5px 20px",
        justifyContent: "space-between",
        ["@media (min-width : 1200px)"]: {
            padding: "0px 2vw"
        },
        "& ul": {
            listStyle: "none",
            display: "flex",
            margin: 0,
            alignItems: "center",
            "& a": {
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                padding: "0px 15px",
                textTransform: "capitalize",
                color: "#000",
                fontSize: 13,
                cursor: "pointer",
                textDecoration: "none",
                "&:hover ,&.active": {
                    color: "green"
                }
            }
        }
    },
    logo: {
        height: 40,
        objectFit: "contain",
        // marginRight: 40,
        display: "flex",
        justifyContent: "center",
        transition: "all 0.3s"
    },
    drawer: {
        zIndex: 1500,
        background: "#fff",
        position: "fixed",
        top: 0,
        left: 0,
        padding: 10,
        paddingTop: 10,
        width: "100vw",
        "& ul": {
            display: "flex",
            listStyle: "none",
            padding: 0,
            flexDirection: "column",
            "& a": {
                width: "100%",
                display: "flex",
                alignItems: "center",
                textTransform: "capitalize",
                padding: 15
            },
            "& .css-i4bv87-MuiSvgIcon-root": {
                color: "inherit"
            },
            "& li ": {
                "& span": {
                    paddingLeft: 15
                },
                "& a:hover , & a:active , & a.active": {
                    background: "#f902",
                    color: "#cea666",
                    fontWeight: 700
                }
            }
        }
    },
    metric: {
        padding: 5,
        borderRadius: 20,
        background: "#fff",
        display: "flex",
        "& span": {
            display: "flex",
            padding: "5px 30px",
            borderRadius: 20,
            "&.active": {
                color: "#fff",
                background: "#fff"
            }
        }
    }
});
function AppToolbar({ route , children , background , opencart =false  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const { 0: notifications , 1: setNotifications  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)();
    const { 0: openCartDialog , 1: setOpenCartDialog  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(opencart);
    const classes = useStyles();
    const { 0: menuOpen , 1: setMenuOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
    const login = "/login";
    const { cartState , authDispatch , authState  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useContext)(_context__WEBPACK_IMPORTED_MODULE_13__/* .GlobalContext */ .k);
    const routes = [
        {
            href: "/",
            active: route === "home",
            label: "Home"
        },
        {
            href: "/shop",
            active: route === "shop",
            label: "Shop"
        },
        {
            href: "/collections",
            active: route === "collections",
            label: "Collections"
        },
        {
            href: "/category",
            active: route === "category",
            label: "Category"
        }, 
    ];
    const Drawer = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classes.drawer,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "0vh 3.5vw"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        style: {
                            marginBottom: 20
                        },
                        className: classes.logo,
                        src: "/img/logo.png"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ButtonBase, {
                        onClick: ()=>{
                            setMenuOpen(false);
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1___default()), {
                            sx: {
                                marginBottom: 3
                            }
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                children: [
                    routes.map((cur)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                onClick: ()=>router.push(cur.href),
                                className: cur.active ? "active" : "",
                                children: [
                                    cur.icon,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: cur.label
                                    })
                                ]
                            })
                        }, cur.label)),
                    !authState?.loggedIn && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                        onClick: ()=>{
                            router.push("/auth/login");
                        },
                        variant: "contained",
                        size: "small",
                        style: {
                            marginBottom: 10
                        },
                        children: "Log In"
                    }),
                    authState?.loggedIn && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                        onClick: ()=>{
                            const r = (0,_context_actions_auth__WEBPACK_IMPORTED_MODULE_14__/* .logoutHandler */ .Sl)(authDispatch);
                            if (r) {
                                router.push("/");
                            }
                        },
                        variant: "contained",
                        size: "small",
                        color: "error",
                        children: "Log Out"
                    })
                ]
            })
        ]
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.AppBar, {
        color: "transparent",
        style: {
            background: "#fff",
            boxShadow: "0 5px 20px #0001"
        },
        position: "sticky",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cart_CartView__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                data: cartState.data,
                open: openCartDialog,
                onClose: ()=>{
                    setOpenCartDialog(false);
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Hidden, {
                lgUp: true,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Backdrop, {
                        open: menuOpen,
                        onClick: ()=>setMenuOpen(false)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grow, {
                        in: menuOpen,
                        children: Drawer
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Toolbar, {
                className: classes.toolbar,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Hidden, {
                        smDown: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                children: [
                                    routes.map((cur)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                onClick: ()=>router.push(cur.href),
                                                className: cur.active ? "active" : "",
                                                children: [
                                                    cur.icon,
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: cur.label
                                                    })
                                                ]
                                            })
                                        }, cur.href)),
                                    authState?.loggedIn && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                        style: {
                                            marginLeft: 10,
                                            fontSize: 10
                                        },
                                        variant: "contained",
                                        size: "small",
                                        color: "error",
                                        onClick: ()=>{
                                            const r = (0,_context_actions_auth__WEBPACK_IMPORTED_MODULE_14__/* .logoutHandler */ .Sl)(authDispatch);
                                            if (r) {
                                                router.push("/");
                                            }
                                        },
                                        children: "Log Out"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Hidden, {
                            smUp: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                sx: {
                                    marginLeft: "-10%",
                                    color: "#000"
                                },
                                onClick: ()=>setMenuOpen(!menuOpen),
                                children: menuOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CloseOutlined__WEBPACK_IMPORTED_MODULE_2___default()), {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_3___default()), {})
                            })
                        })
                    }),
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Hidden, {
                        smDown: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                width: "30%"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                className: classes.logo,
                                src: "/img/logo2.png"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Hidden, {
                        smUp: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                className: classes.logo,
                                src: "/img/logo2.png"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Hidden, {
                        smDown: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                style: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 10,
                                    marginRight: 5,
                                    gap: 20,
                                    "& .cart:hover": {
                                        color: "#fff"
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_7___default()), {}),
                                    authState.loggedIn ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        style: {
                                            display: "flex",
                                            flexDirection: "column"
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                variant: "caption",
                                                children: authState?.data?.user?.fullName
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                variant: "caption",
                                                children: authState?.data?.user?.email
                                            })
                                        ]
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ButtonBase, {
                                        onClick: ()=>{
                                            router.push("/auth/login");
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_8___default()), {})
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Badge, {
                                        badgeContent: cartState?.data?.length || 0,
                                        color: "primary",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ShoppingBag__WEBPACK_IMPORTED_MODULE_9___default()), {
                                            onClick: ()=>{
                                                setOpenCartDialog(true);
                                            }
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Hidden, {
                        smUp: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Badge, {
                                badgeContent: cartState?.data?.length || 0,
                                color: "primary",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ShoppingBag__WEBPACK_IMPORTED_MODULE_9___default()), {
                                    onClick: ()=>{
                                        setOpenCartDialog(true);
                                    }
                                })
                            })
                        })
                    })
                ]
            })
        ]
    });
}
// const UserProfileNavigator = ({ router }) => {
//   const classes = useStyles();
//   const [isVisible, setIsVisible] = useState(false);
//   const handleClose = () => {
//     setIsVisible(false);
//   };
//   const handleOpen = () => {
//     setIsVisible(true);
//   };
//   return (
//   );
// };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppToolbar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1385:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9484);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Toolbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7661);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3193);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5144);
/* harmony import */ var _context_actions_productsActions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9026);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _context_actions_cart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4235);
/* harmony import */ var _context_actions_categoryAction__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6966);
/* harmony import */ var _context_actions_collectionAction__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9224);
/* harmony import */ var _context_actions_auth__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6095);
/* harmony import */ var _context_actions_paymentAction__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3997);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Toolbar__WEBPACK_IMPORTED_MODULE_3__, _components_Footer__WEBPACK_IMPORTED_MODULE_5__, _context__WEBPACK_IMPORTED_MODULE_7__, _context_actions_productsActions__WEBPACK_IMPORTED_MODULE_8__, _context_actions_cart__WEBPACK_IMPORTED_MODULE_10__, _context_actions_categoryAction__WEBPACK_IMPORTED_MODULE_11__, _context_actions_collectionAction__WEBPACK_IMPORTED_MODULE_12__, _context_actions_auth__WEBPACK_IMPORTED_MODULE_13__, _context_actions_paymentAction__WEBPACK_IMPORTED_MODULE_14__]);
([_components_Toolbar__WEBPACK_IMPORTED_MODULE_3__, _components_Footer__WEBPACK_IMPORTED_MODULE_5__, _context__WEBPACK_IMPORTED_MODULE_7__, _context_actions_productsActions__WEBPACK_IMPORTED_MODULE_8__, _context_actions_cart__WEBPACK_IMPORTED_MODULE_10__, _context_actions_categoryAction__WEBPACK_IMPORTED_MODULE_11__, _context_actions_collectionAction__WEBPACK_IMPORTED_MODULE_12__, _context_actions_auth__WEBPACK_IMPORTED_MODULE_13__, _context_actions_paymentAction__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const useStyles = (0,_mui_styles__WEBPACK_IMPORTED_MODULE_2__.makeStyles)({
    loading: {
        display: "flex",
        height: "100vh",
        width: "100vw",
        alignItems: "center",
        justifyContent: "center",
        position: "fixed",
        top: 0,
        zIndex: 2000
    },
    main: {
        background: "#fff",
        minHeight: "100vh"
    }
});
function MainLayout({ route , loading , title , description , image , children , mobileroute , background ,  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const classes = useStyles();
    const { authState: { loggedIn , data , setup_data  } , productDispatch , cartDispatch , cartState , collectionsDispatch , cartegoryDispatch , adminProductsDispatch , authDispatch , paymentDispatch ,  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useContext)(_context__WEBPACK_IMPORTED_MODULE_7__/* .GlobalContext */ .k);
    // const { cartState } = useContext(GlobalContext);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        setTimeout(()=>{
            (0,_context_actions_productsActions__WEBPACK_IMPORTED_MODULE_8__/* .getAllUserProducts */ .PB)(productDispatch);
            (0,_context_actions_cart__WEBPACK_IMPORTED_MODULE_10__/* .getCart */ .d)(cartDispatch);
            (0,_context_actions_categoryAction__WEBPACK_IMPORTED_MODULE_11__/* .getAllCategory */ .KQ)(cartegoryDispatch);
            (0,_context_actions_collectionAction__WEBPACK_IMPORTED_MODULE_12__/* .getAllCollections */ .Lg)(collectionsDispatch);
            (0,_context_actions_productsActions__WEBPACK_IMPORTED_MODULE_8__/* .getAllAdminProducts */ .c0)(adminProductsDispatch);
            (0,_context_actions_auth__WEBPACK_IMPORTED_MODULE_13__/* .getCurrentUser */ .ts)(authDispatch);
            (0,_context_actions_paymentAction__WEBPACK_IMPORTED_MODULE_14__/* .GetPaymentInfo */ .gJ)(paymentDispatch);
        }, 500);
    // client.defaults.headers.common["Authorization"] = `Bearer ${data.token}`;
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: title || "credo"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: title || "Home | credo"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image",
                        content: image || "/img/logo.png"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "theme-color",
                        content: "#000"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "shortcut icon",
                        href: "/img/logo.png"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: description || "Find And PurChase Your Favourite Clothes"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: description || "Find And PurChase Your Favourite Clothes"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Toolbar__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                route: route
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                className: classes.main,
                children: children
            }),
            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classes.loading,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_9__.CircularProgress, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainLayout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;