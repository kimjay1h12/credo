"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 3768:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ routerLoader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/dist/shared/lib/styled-jsx"
const styled_jsx_namespaceObject = require("next/dist/shared/lib/styled-jsx");
var styled_jsx_default = /*#__PURE__*/__webpack_require__.n(styled_jsx_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/routerLoader.js




const RouterLoader = (props)=>{
    const router = (0,router_.useRouter)();
    const { 0: routing , 1: setRouting  } = (0,external_react_.useState)(false);
    const { 0: routerWidth , 1: setRouterWidth  } = (0,external_react_.useState)(2);
    (0,external_react_.useEffect)(()=>{
        router.events.on("routeChangeStart", ()=>{
            setRouting(true);
            setTimeout(()=>{
                setRouterWidth(15);
            }, 200);
            setTimeout(()=>{
                setRouterWidth(65);
            }, 600);
            setTimeout(()=>{
                setRouterWidth(98);
            }, 800);
        });
        router.events.on("routeChangeComplete", ()=>{
            setTimeout(()=>{
                setRouterWidth(1008);
                setRouting(false);
            }, 800);
        });
    }, []);
    return routing && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: styled_jsx_default().dynamic([
            [
                "5a134a781c2e7fef",
                [
                    props.noShow ? "none" : "#ffffffcc",
                    routerWidth
                ]
            ]
        ]) + " " + "routing animated fadeIn faster",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: styled_jsx_default().dynamic([
                    [
                        "5a134a781c2e7fef",
                        [
                            props.noShow ? "none" : "#ffffffcc",
                            routerWidth
                        ]
                    ]
                ]) + " " + "routing-progress"
            }),
            jsx_runtime_.jsx((styled_jsx_default()), {
                id: "5a134a781c2e7fef",
                dynamic: [
                    props.noShow ? "none" : "#ffffffcc",
                    routerWidth
                ],
                children: `.routing.__jsx-style-dynamic-selector{-webkit-transition:all.3s;-moz-transition:all.3s;-o-transition:all.3s;transition:all.3s;position:fixed;top:0;left:0;width:100vw;z-index:5000;background:${props.noShow ? "none" : "#ffffffcc"}}.routing-progress.__jsx-style-dynamic-selector{background:var(--primary);-webkit-filter:brightness(70%);filter:brightness(70%);height:5px;width:${routerWidth}%;-webkit-transition:all 1s;-moz-transition:all 1s;-o-transition:all 1s;transition:all 1s}`
            })
        ]
    });
};
/* harmony default export */ const routerLoader = (RouterLoader);


/***/ }),

/***/ 8510:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_theme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9742);
/* harmony import */ var _components_routerLoader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3768);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5144);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context__WEBPACK_IMPORTED_MODULE_4__]);
_context__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ThemeProvider, {
            theme: _styles_theme__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_routerLoader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);

const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.createTheme)({
    typography: {
        fontFamily: "main, Arial, sans-serif"
    },
    components: {
        MuiDialog: {
            styleOverrides: {
                paper: {
                    borderRadius: 5
                }
            }
        },
        MuiDialogTitle: {
            styleOverrides: {
                root: {
                    paddingTop: 40
                }
            },
            defaultProps: {
                fontWeight: 700
            }
        },
        MuiTypography: {
            styleOverrides: {
                fontFamily: "revert-layer"
            }
        },
        MuiButton: {
            defaultProps: {
                disableElevation: true
            },
            styleOverrides: {
                contained: {
                    textTransform: "capitalize"
                },
                text: {
                    textTransform: "capitalize"
                }
            }
        }
    },
    palette: {
        mode: "light",
        primary: {
            main: "#000000",
            contrastText: "#fff"
        },
        secondary: {
            main: "#4D4D4D",
            contrastText: "#fff"
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (theme);


/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [144], () => (__webpack_exec__(8510)));
module.exports = __webpack_exports__;

})();