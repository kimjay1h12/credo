(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[3561],{8456:function(e,r,t){"use strict";t.d(r,{Z:function(){return N}});var a=t(1048),n=t(2793),i=t(7294),s=t(512),o=t(4780),c=t(917),l=t(8216),u=t(1657),d=t(948),h=t(1588),f=t(4867);function v(e){return(0,f.Z)("MuiCircularProgress",e)}(0,h.Z)("MuiCircularProgress",["root","determinate","indeterminate","colorPrimary","colorSecondary","svg","circle","circleDeterminate","circleIndeterminate","circleDisableShrink"]);var m=t(5893);const k=["className","color","disableShrink","size","style","thickness","value","variant"];let g,p,x,Z,y=e=>e;const S=44,b=(0,c.F4)(g||(g=y`
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
`)),w=(0,c.F4)(p||(p=y`
  0% {
    stroke-dasharray: 1px, 200px;
    stroke-dashoffset: 0;
  }

  50% {
    stroke-dasharray: 100px, 200px;
    stroke-dashoffset: -15px;
  }

  100% {
    stroke-dasharray: 100px, 200px;
    stroke-dashoffset: -125px;
  }
`)),C=(0,d.ZP)("span",{name:"MuiCircularProgress",slot:"Root",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.root,r[t.variant],r[`color${(0,l.Z)(t.color)}`]]}})((({ownerState:e,theme:r})=>(0,n.Z)({display:"inline-block"},"determinate"===e.variant&&{transition:r.transitions.create("transform")},"inherit"!==e.color&&{color:(r.vars||r).palette[e.color].main})),(({ownerState:e})=>"indeterminate"===e.variant&&(0,c.iv)(x||(x=y`
      animation: ${0} 1.4s linear infinite;
    `),b))),P=(0,d.ZP)("svg",{name:"MuiCircularProgress",slot:"Svg",overridesResolver:(e,r)=>r.svg})({display:"block"}),j=(0,d.ZP)("circle",{name:"MuiCircularProgress",slot:"Circle",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.circle,r[`circle${(0,l.Z)(t.variant)}`],t.disableShrink&&r.circleDisableShrink]}})((({ownerState:e,theme:r})=>(0,n.Z)({stroke:"currentColor"},"determinate"===e.variant&&{transition:r.transitions.create("stroke-dashoffset")},"indeterminate"===e.variant&&{strokeDasharray:"80px, 200px",strokeDashoffset:0})),(({ownerState:e})=>"indeterminate"===e.variant&&!e.disableShrink&&(0,c.iv)(Z||(Z=y`
      animation: ${0} 1.4s ease-in-out infinite;
    `),w)));var N=i.forwardRef((function(e,r){const t=(0,u.Z)({props:e,name:"MuiCircularProgress"}),{className:i,color:c="primary",disableShrink:d=!1,size:h=40,style:f,thickness:g=3.6,value:p=0,variant:x="indeterminate"}=t,Z=(0,a.Z)(t,k),y=(0,n.Z)({},t,{color:c,disableShrink:d,size:h,thickness:g,value:p,variant:x}),b=(e=>{const{classes:r,variant:t,color:a,disableShrink:n}=e,i={root:["root",t,`color${(0,l.Z)(a)}`],svg:["svg"],circle:["circle",`circle${(0,l.Z)(t)}`,n&&"circleDisableShrink"]};return(0,o.Z)(i,v,r)})(y),w={},N={},_={};if("determinate"===x){const e=2*Math.PI*((S-g)/2);w.strokeDasharray=e.toFixed(3),_["aria-valuenow"]=Math.round(p),w.strokeDashoffset=`${((100-p)/100*e).toFixed(3)}px`,N.transform="rotate(-90deg)"}return(0,m.jsx)(C,(0,n.Z)({className:(0,s.Z)(b.root,i),style:(0,n.Z)({width:h,height:h},N,f),ownerState:y,ref:r,role:"progressbar"},_,Z,{children:(0,m.jsx)(P,{className:b.svg,ownerState:y,viewBox:"22 22 44 44",children:(0,m.jsx)(j,{className:b.circle,style:w,ownerState:y,cx:S,cy:S,r:(S-g)/2,fill:"none",strokeWidth:g})})}))}))},8746:function(e,r,t){(window.__NEXT_P=window.__NEXT_P||[]).push(["/dashboard/category/add",function(){return t(5128)}])},5128:function(e,r,t){"use strict";t.r(r);var a=t(7568),n=t(4051),i=t.n(n),s=t(5893),o=t(7294),c=t(845),l=t(628),u=t(5861),d=t(6886),h=t(1903),f=t(9417),v=t(8456),m=t(6966),k=t(2579),g=t(1163),p=(0,l.Z)({root:{padding:50},content:{backgroundColor:"#fff",borderRadius:10,padding:20,marginBottom:10}});r.default=function(){var e=(0,o.useState)(null),r=(e[0],e[1],(0,o.useState)(null)),t=(r[0],r[1],(0,g.useRouter)(),(0,o.useState)("")),n=t[0],l=t[1],x=(0,o.useState)(!1),Z=x[0],y=x[1],S=(0,o.useContext)(k.k),b=(S.cartDispatch,S.cartegoryDispatch),w=function(){var e=(0,a.Z)(i().mark((function e(){return i().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return y(!0),e.next=3,(0,m.JP)(b,{title:n});case 3:e.sent&&(alert("Category Created Successfully"),Router.back()),y(!1);case 6:case"end":return e.stop()}}),e)})));return function(){return e.apply(this,arguments)}}(),C=p();return(0,s.jsx)(c.Z,{active:"category",children:(0,s.jsxs)("div",{className:C.root,children:[(0,s.jsx)(u.Z,{fontWeight:600,mb:2,variant:"h5",children:"Create category"}),(0,s.jsx)(d.ZP,{container:!0,spacing:6,children:(0,s.jsx)(d.ZP,{item:!0,xs:20,md:7,children:(0,s.jsx)("div",{className:C.content,children:(0,s.jsx)(h.Z,{value:n,onChange:function(e){l(e.target.value)},style:{marginBottom:10},label:"Title",fullWidth:!0,size:"small"})})})}),(0,s.jsx)("div",{style:{display:"flex",alignItems:"center",justifyContent:"center"},children:(0,s.jsx)(f.Z,{disabled:""===n,onClick:function(){w()},size:"small",sx:{backgroundColor:"#1872F6",color:"#fff",marginTop:2},children:Z?(0,s.jsx)(v.Z,{}):" Create Category"})})]})})}}},function(e){e.O(0,[5861,771,628,1903,2251,6886,2782,6242,845,9774,2888,179],(function(){return r=8746,e(e.s=r);var r}));var r=e.O();_N_E=r}]);